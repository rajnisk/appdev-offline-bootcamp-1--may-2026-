from flask_restful import Resource


class Health(Resource):
    def get(self):
        return {"status": "ok"}

class HelloWorld(Resource):
    def get(self):
        return {"hello": "world!"}